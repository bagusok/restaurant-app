const imageMedium = "https://restaurant-api.dicoding.dev/images/medium/";
